#!/bin/bash

cp -av * /pool/Flores/Flore.img/photos
/pool/Flores/Flore.db/bin/fldb.mkthumb.py

